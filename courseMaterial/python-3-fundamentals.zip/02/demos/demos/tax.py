amount = 200
tax = 0.07
total = amount + amount*tax
print(total)