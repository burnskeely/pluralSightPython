
expenses = [10.50, 8, 5, 15, 20, 5, 3]

total = sum(expenses)

print('You spent $', total, sep = '')